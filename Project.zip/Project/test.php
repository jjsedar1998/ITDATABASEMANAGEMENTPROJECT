<HTML>
<?php $name= "Austin";
$x=1; $x="....";
?>
<br> Welcome <?php echo "$name". $x ; ?>
</HTML>