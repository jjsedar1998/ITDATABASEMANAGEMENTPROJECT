<?php
$dbhostname     = 'imc.kean.edu';
$dbusername = 'sedarj';
$dbpassword  = '1165119';
$dbname     = 'TECH3740';
?>
